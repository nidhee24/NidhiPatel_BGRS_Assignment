import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import { loadPerson } from '../store/actions/action';


import Person from './Person';


const Characters = ({ myperson, startLoadingPerson }) => {
  useEffect(() => {
    startLoadingPerson();
    console.log(myperson);
  }, []);
  return (
    <div>
      
      {myperson.loading ? (
        <h2>loading</h2>
      ) : myperson.error ? (
        <h2>{myperson.error} </h2>
      ) : (
        <div>
          <h2>Character List</h2>
          <div>
            {myperson.people &&
              myperson.people.map((tq) => (
                <Person
                  key={tq._id}
                  id={tq._id}
                  name={tq.name}
                />
                
              ))}
             
          </div>
        </div>
      )}
    </div>
  );
};

//connect state to props
const mapStateToProps = (state) => {
  return {
    myperson: state.tds,
  };
};

//dispatch functions
const mapDispatchToProps = (dispatch) => {
  return {
    
    startLoadingPerson: () => dispatch(loadPerson()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Characters);