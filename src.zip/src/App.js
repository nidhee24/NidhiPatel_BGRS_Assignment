import logo from './logo.svg';
import './App.css';
import Characters from './components/Characters';

function App() {
  return (
    <div>
      <Characters />
    </div>
  );
}

export default App;
