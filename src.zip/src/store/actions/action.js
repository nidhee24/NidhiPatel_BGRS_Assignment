import axios from 'axios';
export const ADD_PERSON = 'ADD_PERSON';
export const REMOVE_PERSON = 'REMOVE_PERSON';

export const LOAD_PERSON_IN_PROGRESS = 'LOAD_PERSON_IN_PROGRESS';

//action creators
export const loadPersonInProgress = () => ({
  type: LOAD_PERSON_IN_PROGRESS,
});

export const LOAD_PERSON_SUCCESS = 'LOAD_PERSON_SUCCESS';


export const loadPersonSuccess = (person) => ({
  type: LOAD_PERSON_SUCCESS,
  payload: person,
});

export const LOAD_PERSON_FAILURE = 'LOAD_PERSON_FAILURE';

//action creators
export const loadPersonFailure = (error) => ({
  type: LOAD_PERSON_FAILURE,
  payload: error,
});

export const loadPerson = () => async (dispatch) => {
  try {
    dispatch(loadPersonInProgress());
    const response = await axios(
      'https://swapi.dev/api/people'
    );
    const people = response.data;

    dispatch(loadPersonSuccess(people));
  } catch (e) {
    dispatch(loadPersonFailure(e.message));
  }
};