import React from 'react';

const Person = (props) => {
  return (
    <div>
      <p>{props.name}</p>

    </div>
  );
};

export default Person;